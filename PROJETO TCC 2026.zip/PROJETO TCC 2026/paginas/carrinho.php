<?php
// Garante que o arquivo de dados está disponível
require_once "includes/banco_ficticio.php";

// 1. INTERCEPTA AS AÇÕES DO USUÁRIO (Gatilhos via URL ou Form)
$acao = $_GET['acao'] ?? null;
$idProd = isset($_GET['id']) ? intval($_GET['id']) : null;

if ($acao === 'add' && $idProd) {
    adicionarAoCarrinho($idProd);
    // Redireciona para o próprio carrinho para limpar os parâmetros da URL
    header("Location: index.php?pg=carrinho");
    exit;
}

if ($acao === 'del' && $idProd) {
    removerDoCarrinho($idProd);
    header("Location: index.php?pg=carrinho");
    exit;
}

if ($acao === 'atualizar' && $idProd && isset($_GET['qtd'])) {
    $novaQtd = intval($_GET['qtd']);
    atualizarQuantidadeCarrinho($idProd, $novaQtd);
    header("Location: index.php?pg=carrinho");
    exit;
}

// 2. MONTA OS DADOS DO CARRINHO PARA EXIBIR NA TELA
$itensCarrinho = $_SESSION['carrinho'] ?? [];
$produtosNoCarrinho = [];
$valorTotalCarrinho = 0;

foreach ($itensCarrinho as $id => $quantidade) {
    $prod = buscarProdutoPorId($id);
    if ($prod) {
        // Calculamos o subtotal deste produto específico (Preço x Quantidade)
        $subtotal = $prod['preco'] * $quantidade;
        $valorTotalCarrinho += $subtotal;

        // Adicionamos no nosso array auxiliar de exibição
        $produtosNoCarrinho[] = [
            'id' => $prod['id'],
            'nome' => $prod['nome'],
            'preco' => $prod['preco'],
            'imagem' => $prod['imagem'],
            'quantidade' => $quantidade,
            'subtotal' => $subtotal
        ];
    }
}
?>

<div class="max-w-6xl mx-auto px-4 py-12">
    <h1 class="text-3xl font-black text-gray-800 mb-8 uppercase tracking-tighter">Seu Carrinho<span class="text-indigo-600">.</span></h1>

    <?php if (empty($produtosNoCarrinho)): ?>
        <div class="text-center py-16 bg-white border border-gray-100 rounded-3xl p-8 shadow-sm max-w-md mx-auto">
            <i class="ph ph-shopping-cart-simple text-6xl text-gray-300 mb-4 block"></i>
            <h2 class="text-xl font-bold text-gray-700 mb-2">Seu carrinho está vazio</h2>
            <p class="text-gray-400 text-sm mb-6">Que tal voltar à vitrine e escolher alguns produtos incríveis?</p>
            <a href="index.php" class="inline-block bg-indigo-600 text-white font-bold px-6 py-3 rounded-xl hover:bg-indigo-700 transition shadow-lg shadow-indigo-100">
                Voltar para a Loja
            </a>
        </div>
    <?php else: ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

            <div class="lg:col-span-2 space-y-4">
                <?php foreach ($produtosNoCarrinho as $item): ?>
                    <div class="bg-white border border-gray-100 p-4 rounded-2xl flex items-center gap-4 shadow-sm hover:border-gray-200 transition">
                        <img src="<?php echo $item['imagem']; ?>" class="w-20 h-20 rounded-xl object-cover bg-gray-50 flex-shrink-0">

                        <div class="flex-grow">
                            <h3 class="font-bold text-gray-800 text-base leading-tight"><?php echo $item['nome']; ?></h3>
                            <p class="text-xs text-gray-400 font-semibold mt-1">R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?> cada</p>
                        </div>

                        <div class="flex items-center border border-gray-200 rounded-xl bg-gray-50 overflow-hidden">
                            <a href="index.php?pg=carrinho&acao=atualizar&id=<?php echo $item['id']; ?>&qtd=<?php echo $item['quantidade'] - 1; ?>"
                                class="px-3 py-1.5 hover:bg-gray-200 text-gray-500 font-bold transition text-xs">-</a>

                            <span class="px-3 font-bold text-sm text-gray-700 font-mono"><?php echo $item['quantidade']; ?></span>

                            <a href="index.php?pg=carrinho&acao=atualizar&id=<?php echo $item['id']; ?>&qtd=<?php echo $item['quantidade'] + 1; ?>"
                                class="px-3 py-1.5 hover:bg-gray-200 text-gray-500 font-bold transition text-xs">+</a>
                        </div>

                        <div class="text-right min-w-[100px]">
                            <p class="font-black text-indigo-600 text-sm">R$ <?php echo number_format($item['subtotal'], 2, ',', '.'); ?></p>
                            <a href="index.php?pg=carrinho&acao=del&id=<?php echo $item['id']; ?>" class="text-red-400 hover:text-red-600 text-xs font-bold inline-block mt-1 transition">
                                Remover
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="bg-white border border-gray-100 p-6 rounded-3xl h-fit shadow-sm space-y-6">
                <h2 class="text-lg font-bold text-gray-800 border-b border-gray-50 pb-4">Resumo do Pedido</h2>

                <div class="flex justify-between items-center text-sm text-gray-500">
                    <span>Quantidade de itens</span>
                    <span class="font-bold text-gray-700 font-mono"><?php echo array_sum($itensCarrinho); ?></span>
                </div>

                <div class="flex justify-between items-center border-t border-gray-50 pt-4">
                    <span class="text-base font-bold text-gray-800">Total do Pedido</span>
                    <span class="text-xl font-black text-indigo-600">R$ <?php echo number_format($valueTotalCarrinho ?? $valorTotalCarrinho, 2, ',', '.'); ?></span>
                </div>

                <button class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-100 transition duration-300 flex items-center justify-center gap-2">
                    <i class="ph ph-credit-card"></i> Fechar Pedido
                </button>

                <a href="index.php" class="block text-center text-xs text-gray-400 hover:text-gray-600 font-bold transition">
                    Continuar Comprando
                </a>
            </div>

        </div>

    <?php endif; ?>
</div>