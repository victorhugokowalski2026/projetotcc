<?php
/**
 * ARQUIVO: includes/banco_dados.php
 * OBJETIVO: Centralizar o acesso aos dados do sistema.
 * No futuro, mudaremos o miolo destas funções para conectar ao MySQL.
 */

// Função interna inteligente para ler o JSON descobrindo o caminho correto
function lerBancoJson() {
    $caminho = "data/produtos.json";
    
    // Se não achar o arquivo na pasta atual, tenta subir um nível (caso esteja no admin)
    if (!file_exists($caminho)) {
        $caminho = "../data/produtos.json";
    }
    
    if (!file_exists($caminho)) {
        return [];
    }
    
    $conteudo = file_get_contents($caminho);
    return json_decode($conteudo, true) ?? [];
}

// Retorna todos os produtos (Útil para o Admin ver tudo, ativos e inativos)
function listarProdutos() {
    return lerBancoJson();
}

// Retorna apenas os produtos ATIVOS (Útil para a vitrine pública da loja)
function listarProdutosAtivos() {
    $todos = lerBancoJson();
    // Filtra o array mantendo apenas quem tem o campo 'ativo' igual a true
    return array_filter($todos, function($p) {
        return isset($p['ativo']) ? $p['ativo'] === true : true;
    });
}

// Busca um produto específico pelo ID
function buscarProdutoPorId($id) {
    $produtos = lerBancoJson();
    foreach ($produtos as $p) {
        if ($p['id'] == $id) {
            return $p;
        }
    }
    return null;
}

// Salva um NOVO produto (Atualizado para incluir o campo 'ativo' como padrão)
function salvarProduto($novoProduto) {
    $caminho = "../data/produtos.json";
    $produtosAtuais = listarProdutos();
    
    if (!empty($produtosAtuais)) {
        $ultimoProduto = end($produtosAtuais);
        $novoProduto['id'] = $ultimoProduto['id'] + 1;
    } else {
        $novoProduto['id'] = 1;
    }
    
    // Todo produto novo já nasce ATIVO (true) no sistema
    $novoProduto['ativo'] = true;
    
    $produtosAtuais[] = $novoProduto;
    $jsonTexto = json_encode($produtosAtuais, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents($caminho, $jsonTexto) !== false;
}

// Salva as alterações de um produto existente (EDITAR ou INATIVAR)
function atualizarProduto($id, $dadosAtualizados) {
    $caminho = "../data/produtos.json";
    $produtos = listarProdutos();
    
    // Percorre a lista para achar o produto que queremos alterar
    foreach ($produtos as $chave => $p) {
        if ($p['id'] == $id) {
            // Mescla os dados antigos com os novos que o usuário editou
            $produtos[$chave] = array_merge($p, $dadosAtualizados);
            
            // Grava a lista atualizada de volta no JSON
            $jsonTexto = json_encode($produtos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            return file_put_contents($caminho, $jsonTexto) !== false;
        }
    }
    return false;
}

// ==========================================
// FUNÇÕES PARA O GERENCIAMENTO DE CATEGORIAS
// ==========================================

// Função para ler o arquivo de categorias
function listarCategorias() {
    $caminho = "data/categorias.json"; // Se a chamada partir da raiz
    
    // Se quem chamou foi o painel admin, precisamos subir um nível de pasta
    if (!file_exists($caminho)) {
        $caminho = "../data/categorias.json";
    }
    
    // Se o arquivo ainda não existir, retorna um array vazio
    if (!file_exists($caminho)) {
        return [];
    }
    
    $conteudo = file_get_contents($caminho);
    return json_decode($conteudo, true) ?? [];
}

// Função para salvar uma nova categoria no arquivo JSON
function salvarCategoria($novaCategoria) {
    // 1. Pegamos as categorias que já existem
    $categoriasAtuais = listarCategorias();
    
    // 2. Lógica de ID automático para a categoria
    if (!empty($categoriasAtuais)) {
        $ultima = end($categoriasAtuais);
        $novaCategoria['id'] = $ultima['id'] + 1;
    } else {
        $novaCategoria['id'] = 1;
    }
    
    // 3. Adiciona a nova categoria no final do array
    $categoriasAtuais[] = $novaCategoria;
    
    // 4. Converte o array para texto JSON
    $jsonTexto = json_encode($categoriasAtuais, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
    // 5. Salva no arquivo físico
    $caminho = "../data/categorias.json";
    file_put_contents($caminho, $jsonTexto);
    
    return true;
}

// ... (mantenha as funções de produtos e categorias acima) ...

// ==========================================
// FUNÇÕES PARA O GERENCIAMENTO DE USUÁRIOS
// ==========================================

// Função para ler o arquivo de usuários
function listarUsuarios() {
    $caminho = "data/usuarios.json";
    
    if (!file_exists($caminho)) {
        $caminho = "../data/usuarios.json";
    }
    
    if (!file_exists($caminho)) {
        return [];
    }
    
    $conteudo = file_get_contents($caminho);
    return json_decode($conteudo, true) ?? [];
}

// Função para salvar um novo usuário com senha criptografada
function salvarUsuario($novoUsuario) {
    $caminho = "../data/usuarios.json";
    $usuariosAtuais = listarUsuarios();
    
    // Lógica de ID automático
    if (!empty($usuariosAtuais)) {
        $ultimo = end($usuariosAtuais);
        $novoUsuario['id'] = $ultimo['id'] + 1;
    } else {
        $novoUsuario['id'] = 1;
    }
    
    // CRUCIAL PARA SEGURANÇA: Criptografa a senha antes de salvar no JSON.
    // O algoritmo PASSWORD_DEFAULT gera uma chave segura de 60 caracteres (BCRYPT).
    $novoUsuario['senha'] = password_hash($novoUsuario['senha'], PASSWORD_DEFAULT);
    
    $usuariosAtuais[] = $novoUsuario;
    $jsonTexto = json_encode($usuariosAtuais, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents($caminho, $jsonTexto) !== false;
}
// Busca um usuário específico pelo ID
function buscarUsuarioPorId($id) {
    $usuarios = listarUsuarios();
    foreach ($usuarios as $u) {
        if ($u['id'] == $id) {
            return $u;
        }
    }
    return null;
}

// Salva as alterações de um usuário existente (EDITAR ou INATIVAR)
function atualizarUsuario($id, $dadosAtualizados) {
    $caminho = "../data/usuarios.json";
    $usuarios = listarUsuarios();
    
    foreach ($usuarios as $chave => $u) {
        if ($u['id'] == $id) {
            
            // Se no formulário de edição o usuário digitou uma nova senha,
            // precisamos criptografá-la antes de salvar
            if (!empty($dadosAtualizados['senha'])) {
                $dadosAtualizados['senha'] = password_hash($dadosAtualizados['senha'], PASSWORD_DEFAULT);
            } else {
                // Se o campo senha veio vazio, removemos do array para manter a senha antiga
                unset($dadosAtualizados['senha']);
            }
            
            // Mescla os dados antigos do usuário com as alterações novas
            $usuarios[$chave] = array_merge($u, $dadosAtualizados);
            
            // Salva a lista completa atualizada no arquivo JSON
            $jsonTexto = json_encode($usuarios, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            return file_put_contents($caminho, $jsonTexto) !== false;
        }
    }
    return false;
}
// ==========================================
// FUNÇÕES PARA O CARRINHO DE COMPRAS (SESSÃO)
// ==========================================

function adicionarAoCarrinho($idProduto, $quantidade = 1) {
    // 1. Se a sessão não estiver ativa por algum motivo, ativa ela aqui
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // 2. Força a criação do array do carrinho na sessão global
    if (!isset($_SESSION['carrinho']) || !is_array($_SESSION['carrinho'])) {
        $_SESSION['carrinho'] = [];
    }

    // 3. Adiciona ou soma a quantidade
    if (isset($_SESSION['carrinho'][$idProduto])) {
        $_SESSION['carrinho'][$idProduto] += $quantidade;
    } else {
        $_SESSION['carrinho'][$idProduto] = $quantidade;
    }
    
    return true;
}

// Remove completamente um produto do carrinho
function removerDoCarrinho($idProduto) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (isset($_SESSION['carrinho'][$idProduto])) {
        unset($_SESSION['carrinho'][$idProduto]); // Apaga a chave do array
        return true;
    }
    return false;
}

// Atualiza a quantidade exata de um produto (útil para os botões de + e - no carrinho)
function atualizarQuantidadeCarrinho($idProduto, $novaQuantidade) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Se a quantidade for zero ou negativa, removemos o produto
    if ($novaQuantidade <= 0) {
        return removerDoCarrinho($idProduto);
    }

    if (isset($_SESSION['carrinho'][$idProduto])) {
        $_SESSION['carrinho'][$idProduto] = intval($novaQuantidade);
        return true;
    }
    return false;
}
?>