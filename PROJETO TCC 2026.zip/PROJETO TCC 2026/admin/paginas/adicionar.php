<?php
// Importamos o centralizador de dados
require_once "../includes/banco_ficticio.php";

// Buscamos as categorias dinâmicas para o select
$listaCategorias = listarCategorias();

// Variáveis de feedback para o usuário
$sucesso = null;
$erro = null;

// Verifica se o formulário foi enviado via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Captura e limpa os campos de texto comuns
    $nome = htmlspecialchars(trim($_POST['nome'] ?? ''));
    $categoria = htmlspecialchars(trim($_POST['categoria'] ?? ''));
    $preco = filter_var($_POST['preco'] ?? 0, FILTER_VALIDATE_FLOAT);
    $descricao = htmlspecialchars(trim($_POST['descricao'] ?? ''));

    // Captura o arquivo de imagem vindo da variável superglobal $_FILES
    // 'foto_produto' é o "name" do campo que colocamos no HTML abaixo
    $arquivoImagem = $_FILES['foto_produto'] ?? null;

    // VALIDAÇÃO BÁSICA DOS CAMPOS DE TEXTO
    if (empty($nome) || empty($categoria) || $preco <= 0 || empty($descricao)) {
        $erro = "Por favor, preencha todos os campos de texto corretamente.";
    }
    // VALIDAÇÃO DO UPLOAD DA IMAGEM
    // 'error' igual a 0 significa que o upload para a pasta temporária do servidor deu certo
    elseif (!$arquivoImagem || $arquivoImagem['error'] !== UPLOAD_ERR_OK) {
        $erro = "Houve um erro no envio do arquivo de imagem. Tente novamente.";
    } else {
        // --- PROCESSO DE TRATAMENTO DO ARQUIVO ---

        // 1. Pegamos a extensão do arquivo (ex: .jpg, .png) convertendo para letras minúsculas
        $extensao = strtolower(pathinfo($arquivoImagem['name'], PATHINFO_EXTENSION));

        // 2. Filtro de Segurança: Criamos uma lista de extensões permitidas
        $extesoesPermitidas = ['jpg', 'jpeg', 'png', 'webp'];

        // in_array(o_que_procurar, onde_procurar) -> Devolve true ou false
        if (!in_array($extensao, $extesoesPermitidas)) {
            $erro = "Formato inválido! Só aceitamos imagens JPG, JPEG, PNG ou WEBP.";
        } else {

            // 3. Geramos um nome único usando a função uniqid() combinada com o timestamp atual.
            // Isso evita que, se dois alunos subirem uma imagem chamada "foto.jpg", uma apague a outra.
            $novoNomeArquivo = "prod_" . uniqid() . "_" . time() . "." . $extensao;

            // 4. Definimos onde o arquivo final será guardado fisicamente no projeto.
            // A imagem ficará na pasta 'uploads/' que está na raiz do projeto.
            $pastaDestino = "../uploads/" . $novoNomeArquivo;

            // 5. Movemos o arquivo da pasta temporária secreta do PHP para a nossa pasta definitiva
            if (move_uploaded_file($arquivoImagem['tmp_name'], $pastaDestino)) {

                // O caminho que vamos salvar no JSON será amigável para a área pública ler.
                // Como a área pública está na raiz, o caminho começa direto da pasta uploads/
                $caminhoParaSalvarNoJson = "uploads/" . $novoNomeArquivo;

                // Montamos o array final do produto com o caminho gerado
                $dadosProduto = [
                    "nome" => $nome,
                    "preco" => $preco,
                    "categoria" => $categoria,
                    "imagem" => $caminhoParaSalvarNoJson, // Salvando o caminho local da imagem!
                    "descricao" => $descricao
                ];

                // Gravamos no arquivo JSON através da nossa função existente
                if (salvarProduto($dadosProduto)) {
                    $sucesso = "Produto <strong>$nome</strong> cadastrado com sucesso com imagem armazenada localmente!";
                    $_POST = array(); // Limpa o formulário
                } else {
                    $erro = "Ocorreu um erro técnico ao tentar salvar os dados no catálogo.";
                }
            } else {
                $erro = "Falha ao mover a imagem para a pasta do servidor. Verifique as permissões da pasta.";
            }
        }
    }
}
?>

<div class="mb-8">
    <a href="index.php?pg=produtos" class="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-gray-600 mb-4 transition">
        <i class="ph ph-arrow-left"></i> Voltar para a listagem
    </a>
    <h1 class="text-3xl font-black text-gray-800">Adicionar Novo Produto</h1>
    <p class="text-gray-500 text-sm">Preencha os campos abaixo e faça o upload da imagem do item.</p>
</div>

<div class="bg-white border border-gray-100 rounded-3xl p-8 max-w-2xl shadow-sm">

    <?php if ($sucesso): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-800 p-4 rounded-xl text-sm flex items-center gap-3">
            <i class="ph ph-check-circle text-xl text-green-600"></i>
            <div><?php echo $sucesso; ?></div>
        </div>
    <?php endif; ?>

    <?php if ($erro): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-800 p-4 rounded-xl text-sm flex items-center gap-3">
            <i class="ph ph-warning-circle text-xl text-red-600"></i>
            <div><?php echo $erro; ?></div>
        </div>
    <?php endif; ?>

    <form action="index.php?pg=adicionar" method="POST" enctype="multipart/form-data" class="space-y-6">

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div class="flex flex-col gap-2">
                <label for="nome" class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Nome do Produto</label>
                <input type="text" id="nome" name="nome" value="<?php echo $_POST['nome'] ?? ''; ?>" required
                    class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition">
            </div>

            <div class="flex flex-col gap-2">
                <label for="categoria" class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Categoria</label>
                <select id="categoria" name="categoria" required
                    class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition appearance-none">
                    <option value="">Selecione...</option>
                    <?php foreach ($listaCategorias as $cat): ?>
                        <option value="<?php echo $cat['nome']; ?>" <?php echo isset($_POST['categoria']) && $_POST['categoria'] == $cat['nome'] ? 'selected' : ''; ?>>
                            <?php echo $cat['nome']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div class="flex flex-col gap-2">
                <label for="preco" class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Preço (R$)</label>
                <input type="number" id="preco" name="preco" step="0.01" value="<?php echo $_POST['preco'] ?? ''; ?>" required placeholder="0.00"
                    class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition">
            </div>

            <div class="flex flex-col gap-2 sm:col-span-2">
                <label for="foto_produto" class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Imagem do Produto (Arquivo)</label>
                <input type="file" id="foto_produto" name="foto_produto" required accept="image/*"
                    class="w-full bg-gray-50 border border-gray-200 rounded-xl p-2 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition file:mr-4 file:py-1.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 file:cursor-pointer">
            </div>
        </div>

        <div class="flex flex-col gap-2">
            <label for="descricao" class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Descrição Detalhada</label>
            <textarea id="descricao" name="descricao" rows="4" required placeholder="Fale sobre o produto..."
                class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition resize-none"><?php echo $_POST['descricao'] ?? ''; ?></textarea>
        </div>

        <button type="submit"
            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-100 transition duration-300 flex items-center justify-center gap-2">
            <i class="ph ph-floppy-disk"></i> Salvar Produto no Catálogo
        </button>
    </form>
</div>