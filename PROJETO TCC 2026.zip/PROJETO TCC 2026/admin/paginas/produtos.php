<?php
    require_once "../includes/banco_ficticio.php"; 
    
    // GATILHO PARA INATIVAR / ATIVAR: Se a URL receber ?acao=status&id=X
    if (isset($_GET['acao']) && $_GET['acao'] === 'status' && isset($_GET['id'])) {
        $idStatus = intval($_GET['id']);
        $prodStatus = buscarProdutoPorId($idStatus);
        
        if ($prodStatus) {
            // Inverte o status atual: se era true vira false, se era false vira true
            $novoStatus = isset($prodStatus['ativo']) ? !$prodStatus['ativo'] : false;
            
            // Salva a alteração do status no JSON
            atualizarProduto($idStatus, ['ativo' => $novoStatus]);
            
            // Redireciona para limpar os parâmetros da URL
            header("Location: index.php?pg=produtos");
            exit;
        }
    }

    // Puxa todos os produtos para renderizar a tabela
    $produtos = listarProdutos();
?>

<div class="flex justify-between items-center mb-10">
    <div>
        <h1 class="text-3xl font-black text-gray-800">Gerenciar Produtos</h1>
        <p class="text-gray-500 text-sm">Controle total do catálogo da sua loja.</p>
    </div>
    <a href="index.php?pg=adicionar" class="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition shadow-lg shadow-indigo-100">
        <i class="ph ph-plus-circle"></i> Novo Produto
    </a>
</div>

<div class="bg-white border border-gray-100 rounded-3xl overflow-hidden shadow-sm">
    <table class="w-full text-left border-collapse">
        <thead class="bg-gray-50 border-b border-gray-100">
            <tr>
                <th class="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Produto</th>
                <th class="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Categoria</th>
                <th class="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Preço</th>
                <th class="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                <th class="p-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Ações</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php foreach ($produtos as $p): 
                // Define se o produto está ativo ou inativo para exibir o selo visual correto
                $isAtivo = isset($p['ativo']) ? $p['ativo'] : true;
            ?>
            <tr class="hover:bg-gray-50 transition <?php echo !$isAtivo ? 'opacity-60 bg-gray-50/50' : ''; ?>">
                <td class="p-4">
                    <div class="flex items-center gap-3">
                        <img src="../<?php echo $p['imagem']; ?>" class="w-10 h-10 rounded-lg object-cover">
                        <span class="font-bold text-gray-700"><?php echo $p['nome']; ?></span>
                    </div>
                </td>
                <td class="p-4 text-sm text-gray-500"><?php echo $p['categoria']; ?></td>
                <td class="p-4 font-bold text-indigo-600">R$ <?php echo number_format($p['preco'], 2, ',', '.'); ?></td>
                
                <td class="p-4">
                    <?php if ($isAtivo): ?>
                        <span class="bg-green-50 text-green-700 text-[10px] font-bold px-2.5 py-1 rounded-full border border-green-100">Ativo</span>
                    <?php else: ?>
                        <span class="bg-gray-100 text-gray-500 text-[10px] font-bold px-2.5 py-1 rounded-full border border-gray-200">Inativo</span>
                    <?php endif; ?>
                </td>
                
                <td class="p-4 text-right space-x-1">
                    <a href="index.php?pg=editar&id=<?php echo $p['id']; ?>" class="inline-block text-blue-500 hover:bg-blue-50 p-2 rounded-lg transition" title="Editar">
                        <i class="ph ph-pencil-simple text-xl"></i>
                    </a>
                    
                    <a href="index.php?pg=produtos&acao=status&id=<?php echo $p['id']; ?>" 
                       class="inline-block p-2 rounded-lg transition <?php echo $isAtivo ? 'text-amber-500 hover:bg-amber-50' : 'text-green-500 hover:bg-green-50'; ?>" 
                       title="<?php echo $isAtivo ? 'Inativar Produto' : 'Ativar Produto'; ?>">
                        <i class="ph <?php echo $isAtivo ? 'ph-eye-slash' : 'ph-eye'; ?> text-xl"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>