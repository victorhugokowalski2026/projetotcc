<?php
require_once "../includes/banco_ficticio.php";
$listaCategorias = listarCategorias();

$sucesso = null;
$erro = null;

// 1. Captura o ID do produto vindo da URL
$id = $_GET['id'] ?? null;
$produto = buscarProdutoPorId($id);

// Se não achar o produto, cancela o acesso
if (!$produto) {
    echo "<h2 class='text-xl font-bold text-red-500'>Produto inválido!</h2>";
    exit;
}

// 2. Processa a atualização do formulário (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = htmlspecialchars(trim($_POST['nome'] ?? ''));
    $categoria = htmlspecialchars(trim($_POST['categoria'] ?? ''));
    $preco = filter_var($_POST['preco'] ?? 0, FILTER_VALIDATE_FLOAT);
    $descricao = htmlspecialchars(trim($_POST['descricao'] ?? ''));
    
    $arquivoImagem = $_FILES['foto_produto'] ?? null;
    $caminhoImagemFinal = $produto['imagem']; // Por padrão, mantém a imagem que já estava salva

    if (empty($nome) || empty($categoria) || $preco <= 0 || empty($descricao)) {
        $erro = "Por favor, preencha todos os campos obrigatórios.";
    } else {
        
        // Se o usuário selecionou uma NOVA foto para upload
        if ($arquivoImagem && $arquivoImagem['error'] === UPLOAD_ERR_OK) {
            $extensao = strtolower(pathinfo($arquivoImagem['name'], PATHINFO_EXTENSION));
            $extesoesPermitidas = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (in_array($extensao, $extesoesPermitidas)) {
                $novoNome = "prod_" . uniqid() . "_" . time() . "." . $extensao;
                if (move_uploaded_file($arquivoImagem['tmp_name'], "../uploads/" . $novoNome)) {
                    $caminhoImagemFinal = "uploads/" . $novoNome; // Altera para o novo caminho
                }
            } else {
                $erro = "Formato de imagem inválido.";
            }
        }

        // Se nenhum erro de validação aconteceu até aqui, atualiza o JSON
        if (!$erro) {
            $dadosAtualizados = [
                "nome" => $nome,
                "categoria" => $categoria,
                "preco" => $preco,
                "descricao" => $descricao,
                "imagem" => $caminhoImagemFinal
            ];

            if (atualizarProduto($id, $dadosAtualizados)) {
                $sucesso = "Produto atualizado com sucesso!";
                // Atualiza os dados da tela com as novas informações salvas
                $produto = buscarProdutoPorId($id);
            } else {
                $erro = "Erro ao salvar as modificações.";
            }
        }
    }
}
?>

<div class="mb-8">
    <a href="index.php?pg=produtos" class="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-gray-600 mb-4 transition">
        <i class="ph ph-arrow-left"></i> Cancelar e Voltar
    </a>
    <h1 class="text-3xl font-black text-gray-800">Editar Produto</h1>
    <p class="text-gray-500 text-sm">Modifique as informações do item #<?php echo $produto['id']; ?>.</p>
</div>

<div class="bg-white border border-gray-100 rounded-3xl p-8 max-w-2xl shadow-sm">

    <?php if ($sucesso): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-800 p-4 rounded-xl text-sm flex items-center gap-3">
            <i class="ph ph-check-circle text-xl text-green-600"></i>
            <div><?php echo $sucesso; ?></div>
        </div>
    <?php endif; ?>

    <?php if ($erro): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-800 p-4 rounded-xl text-sm flex items-center gap-3">
            <i class="ph ph-warning-circle text-xl text-red-600"></i>
            <div><?php echo $erro; ?></div>
        </div>
    <?php endif; ?>

    <form action="index.php?pg=editar&id=<?php echo $produto['id']; ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div class="flex flex-col gap-2">
                <label class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Nome</label>
                <input type="text" name="nome" value="<?php echo $produto['nome']; ?>" required class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition">
            </div>
            <div class="flex flex-col gap-2">
                <label class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Categoria</label>
                <select name="categoria" required class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition appearance-none">
                    <?php foreach ($listaCategorias as $cat): ?>
                        <option value="<?php echo $cat['nome']; ?>" <?php echo $produto['categoria'] == $cat['nome'] ? 'selected' : ''; ?>><?php echo $cat['nome']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div class="flex flex-col gap-2">
                <label class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Preço (R$)</label>
                <input type="number" name="preco" step="0.01" value="<?php echo $produto['preco']; ?>" required class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition">
            </div>
            <div class="flex flex-col gap-2 sm:col-span-2">
                <label class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Substituir Imagem (Opcional)</label>
                <input type="file" name="foto_produto" accept="image/*" class="w-full bg-gray-50 border border-gray-200 rounded-xl p-2 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition file:mr-4 file:py-1.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 file:cursor-pointer">
            </div>
        </div>

        <div class="flex flex-col gap-2">
            <label class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Descrição</label>
            <textarea name="descricao" rows="4" required class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-600 focus:bg-white transition resize-none"><?php echo $produto['descricao']; ?></textarea>
        </div>

        <button type="submit" class="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-4 rounded-xl shadow-lg transition">
            <i class="ph ph-check"></i> Salvar Alterações
        </button>
    </form>
</div>