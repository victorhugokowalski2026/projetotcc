<?php
session_start();

// Importamos o centralizador (repare que o caminho aqui muda pois o login está na raiz da pasta admin/)
require_once "../includes/banco_ficticio.php";

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuarioDigitado = htmlspecialchars(trim($_POST['usuario'] ?? ''));
    $senhaDigitada = $_POST['senha'] ?? '';

    // 1. Puxamos a lista de usuários reais gravados no arquivo JSON
    $usuariosCadastrados = listarUsuarios();
    $usuarioEncontrado = null;

    // 2. Procuramos se existe algum usuário com o login digitado
    foreach ($usuariosCadastrados as $u) {
        if (strtolower($u['login']) === strtolower($usuarioDigitado)) {
            $usuarioEncontrado = $u;
            break;
        }
    }

    // Mude o IF antigo da checagem de login por este:
if ($usuarioEncontrado && password_verify($senhaDigitada, $usuarioEncontrado['senha'])) {
    
    // VERIFICAÇÃO ADICIONAL: O usuário está ativo no sistema?
    $usuarioAtivo = isset($usuarioEncontrado['ativo']) ? $usuarioEncontrado['ativo'] : true;
    
    if (!$usuarioAtivo) {
        $erro = "Esta conta de administrador foi desativada pelo sistema.";
    } else {
        // Se estiver ativo e a senha estiver correta, loga com sucesso!
        $_SESSION['logado'] = true;
        $_SESSION['usuario_nome'] = $usuarioEncontrado['nome'];
        
        header('Location: index.php');
        exit;
    }
} else {
    $erro = "Usuário ou senha inválidos!";
}
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Login | MinimalShop Admin</title>
</head>
<body class="bg-gray-100 h-screen flex items-center justify-center">

    <div class="bg-white p-8 rounded-3xl shadow-xl border border-gray-200 w-full max-w-sm">
        <h1 class="text-2xl font-black text-center mb-6 text-gray-800 uppercase tracking-tighter">Admin<span class="text-indigo-600">.</span></h1>
        
        <?php if ($erro): ?>
            <div class="bg-red-50 text-red-600 p-3 rounded-xl text-xs mb-4 text-center font-bold">
                <?php echo $erro; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <div>
                <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Usuário</label>
                <input type="text" name="usuario" required class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:border-indigo-600 outline-none">
            </div>
            <div>
                <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Senha</label>
                <input type="password" name="senha" required class="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:border-indigo-600 outline-none">
            </div>
            <button type="submit" class="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition shadow-lg shadow-indigo-100">
                Entrar no Painel
            </button>
        </form>
    </div>

</body>
</html>