<?php
// OBRIGATÓRIO E CRUCIAL: Inicializa a sessão antes de qualquer saída de texto ou HTML para o navegador.
// Adicionamos uma checagem preventiva para garantir que ela só inicie se já não estiver ativa.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Importa o arquivo centralizador com as funções de banco fictício e carrinho
require_once "includes/banco_dados.php";

// Captura a página atual através do parâmetro 'pg' na URL. 
// Se não houver parâmetro (ex: apenas index.php), o padrão adotado será a vitrine de 'produtos'.
$pagina = $_GET['pg'] ?? 'produtos';
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <title>MinimalShop | Sua Loja de Tecnologia</title>
</head>

<body class="bg-gray-50 text-gray-900 flex flex-col min-h-screen font-sans antialiased">

    <header class="bg-white border-b border-gray-100 sticky top-0 z-50 backdrop-blur-md bg-white/90">
        <div class="container mx-auto px-6 h-20 flex justify-between items-center">

            <a href="index.php?pg=produtos" class="text-2xl font-black tracking-tight text-gray-900 flex items-center gap-2">
                <i class="ph ph-handbag text-indigo-600"></i> minimal<span class="text-indigo-600">.shop</span>
            </a>

            <nav>
                <ul class="flex gap-8 text-sm font-medium text-gray-600">
                    <li>
                        <a href="index.php?pg=produtos" class="hover:text-indigo-600 transition <?php echo $pagina == 'produtos' ? 'text-indigo-600 font-semibold' : ''; ?>">Produtos</a>
                    </li>
                    <li>
                        <a href="index.php?pg=sobre" class="hover:text-indigo-600 transition <?php echo $pagina == 'sobre' ? 'text-indigo-600 font-semibold' : ''; ?>">Nossa História</a>
                    </li>
                    <li>
                        <a href="index.php?pg=contato" class="hover:text-indigo-600 transition <?php echo $pagina == 'contato' ? 'text-indigo-600 font-semibold' : ''; ?>">Contato</a>
                    </li>
                </ul>
            </nav>

            <div class="flex items-center gap-4 text-xl text-gray-700">
                <button class="hover:text-indigo-600 transition"><i class="ph ph-magnifying-glass"></i></button>
                
                <?php
                // DINÂMICO: Soma todas as quantidades de itens guardadas dentro da gaveta 'carrinho' na sessão do usuário
                $totalItensNoCarrinho = isset($_SESSION['carrinho']) ? array_sum($_SESSION['carrinho']) : 0;
                ?>

                <a href="index.php?pg=carrinho" class="relative p-2 text-gray-600 hover:text-indigo-600 transition">
                    <i class="ph ph-shopping-cart text-2xl"></i>

                    <?php if ($totalItensNoCarrinho > 0): ?>
                        <span class="absolute top-0 right-0 bg-red-500 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-white animate-bounce">
                            <?php echo $totalItensNoCarrinho; ?>
                        </span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </header>

    <main class="container mx-auto px-6 flex-grow py-8">
        <?php
        // Define o caminho físico do arquivo que deve ser incluído na tela
        $arquivo = "paginas/" . $pagina . ".php";

        // Verifica de forma segura se o arquivo existe dentro da pasta 'paginas/' antes de incluí-lo
        if (file_exists($arquivo)) {
            include($arquivo);
        } else {
            // Caso o aluno tente forçar uma página inexistente na URL (ex: ?pg=hack), cai no erro 404 customizado
            echo "
                <div class='text-center py-20'>
                    <i class='ph ph-prohibit text-6xl text-gray-300 mb-4 inline-block'></i>
                    <h1 class='text-2xl font-bold text-gray-800'>Página não encontrada!</h1>
                    <p class='text-gray-400 text-sm mt-1'>O conteúdo que você buscou não existe ou foi removido.</p>
                    <a href='index.php?pg=produtos' class='mt-6 inline-block bg-indigo-50 text-indigo-600 font-bold px-6 py-2.5 rounded-xl hover:bg-indigo-100 transition text-sm'>
                        Voltar para o início
                    </a>
                </div>";
        }
        ?>
    </main>

    <footer class="bg-white border-t border-gray-100 py-12 mt-20">
        <div class="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
            <p class="text-sm text-gray-500">&copy; 2026 minimal.shop. Todos os direitos reservados.</p>
            <div class="flex gap-6 text-sm text-gray-400">
                <a href="#" class="hover:text-gray-600 transition">Políticas de Privacidade</a>
                <a href="#" class="hover:text-gray-600 transition">Termos de Uso</a>
            </div>
        </div>
    </footer>

</body>
</html>